package com.phonepe.rest.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhonePeClinetMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhonePeClinetMasterApplication.class, args);
	}

}
