# PhonePe-Client
How to develop Rest client using Rest Template
