package com.nt.ws.soap;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import com.bharath.ws.trainings.CustomerOrdersPortType;
import com.bharath.ws.trainings.CustomerOrdersService;
import com.bharath.ws.trainings.GetOrdersRequest;
import com.bharath.ws.trainings.GetOrdersResponse;
import com.bharath.ws.trainings.Order;

public class CustomerOrderWsClient {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub
		System.out.println("soap client ..");
		CustomerOrdersService service=new CustomerOrdersService(new URL("http://localhost:8080/wsdlfirst/CustomerOrdersWsImpl?wsdl"));
		
          CustomerOrdersPortType customerOrderPort = service.getCustomerOrdersPort();
          
          GetOrdersRequest request=new GetOrdersRequest();
          request.setCustomerId(BigInteger.valueOf(1));
          
          GetOrdersResponse response=customerOrderPort.getOrders(request);
          
          List<Order> orders =response.getOrder();
          
          System.out.println("number of orders for the customer are :: "+orders.size());
          
          
          
	}

}
