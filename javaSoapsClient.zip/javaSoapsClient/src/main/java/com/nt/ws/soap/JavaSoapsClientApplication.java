package com.nt.ws.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSoapsClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSoapsClientApplication.class, args);
	}

}
