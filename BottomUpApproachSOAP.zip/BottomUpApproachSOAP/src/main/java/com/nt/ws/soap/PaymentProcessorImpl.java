package com.nt.ws.soap;

import com.nt.ws.soap.dto.PaymentProcessorRequest;
import com.nt.ws.soap.dto.PaymentProcessorResponse;

public class PaymentProcessorImpl implements PaymentProcessor{

	
	public PaymentProcessorResponse processPayment(PaymentProcessorRequest paymentProcessorRequest) {
		PaymentProcessorResponse paymentProcessorResponse=new PaymentProcessorResponse();
		paymentProcessorResponse.setResult(true);
		// TODO Auto-generated method stub
		return paymentProcessorResponse;
	}

}
