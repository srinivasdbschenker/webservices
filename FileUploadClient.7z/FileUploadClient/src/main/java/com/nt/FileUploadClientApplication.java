package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadClientApplication.class, args);
	}

}
