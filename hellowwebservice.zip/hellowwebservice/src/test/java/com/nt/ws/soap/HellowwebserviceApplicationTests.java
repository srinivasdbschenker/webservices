package com.nt.ws.soap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellowwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
