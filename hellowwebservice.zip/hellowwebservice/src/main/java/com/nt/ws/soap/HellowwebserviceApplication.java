package com.nt.ws.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellowwebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellowwebserviceApplication.class, args);
	}

}
