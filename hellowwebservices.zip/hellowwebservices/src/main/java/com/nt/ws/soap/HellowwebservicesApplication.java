package com.nt.ws.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellowwebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellowwebservicesApplication.class, args);
	}

}
