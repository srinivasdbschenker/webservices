package com.nt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.entity.User;
import com.nt.repository.UserRepository;

@RestController
public class UserController {
	@Autowired
	UserRepository userRepository;
		
	@GetMapping("/")
	public String userDetails() {
		User user=userRepository.findById(1);
		User user1=(User) userRepository.findByName("rani");
		
		return "raja is great"+user+"\n find by name :: "+user1;
	}
	
	

}
