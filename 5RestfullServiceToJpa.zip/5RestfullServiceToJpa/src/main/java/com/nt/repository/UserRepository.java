package com.nt.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nt.entity.User;

public interface UserRepository extends CrudRepository<User,Long> {
	User findByName(String name);

	  User findById(int id);

}
