insert into user values(1, sysdate(), 'raja');
insert into user values(2, sysdate(), 'rani');
insert into user values(3, sysdate(), 'rao');
insert into user values(4, sysdate(), 'ramesh');
