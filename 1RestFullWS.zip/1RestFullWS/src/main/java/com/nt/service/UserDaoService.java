package com.nt.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nt.bean.User;

@Component
public class UserDaoService {

	
	public static int userCount=5;
	
	private static List<User> users=new ArrayList<>();
	static {
		
	users.add(new User(101,"raja",new Date()));
	users.add(new User(102,"rani",new Date()));
	users.add(new User(103,"rao",new Date()));
	users.add(new User(104,"sandeep",new Date()));

	users.add(new User(105,"ram",new Date()));
	
	}
	
	//methd that retrive all users from the list
	
	public List<User> findAll(){
		return users;
		
		
	}
	
	//method that add the user in the list
	
	public User save(User user) {
		if(user.getId()==null) {
		user.setId(++userCount);
		}
		users.add(user);
		return user;
	}
	
	
	//method that find particular user from the list
	
	public User findOne(int id) {
		for(User user:users) {
			if(user.getId()==id)
				return user;
		}
		return null;
	}
	
	public User deleteById(int id) {
		Iterator<User> iterator=users.iterator();
		while(iterator.hasNext()) {
			User user=iterator.next();
			
			if(user.getId()==id) {
				iterator.remove();
				return user;
			}
		}
		
		return null;
	}
}
