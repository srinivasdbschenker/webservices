package com.nt.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nt.bean.HelloWorldBean;

@RestController
public class HelloController {

	@RequestMapping(method=RequestMethod.GET, path="/helloMessage")
	public String helloMessage() {
		return "Hello , Good Morning";
	}
	
	@GetMapping(path="/helloWorldBean")
	public HelloWorldBean helloWorldBean() {
		return new HelloWorldBean("Hello World");
	}
	
	//@GetMapping(path="/hello-world/path-varaible/{name}")
	@RequestMapping(method=RequestMethod.GET, path="/hello-world/path-varaible/{name}")
	public HelloWorldBean helloworldPathVariable(@PathVariable String name) {
		return new HelloWorldBean(String.format("Hello world path variable , %s", name)); //%s replace with the name
	}
}
