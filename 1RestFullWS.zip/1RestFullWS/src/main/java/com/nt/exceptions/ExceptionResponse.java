package com.nt.exceptions;

import java.util.Date;

public class ExceptionResponse {

	Date date;
	String message;
	String description;
	
	public ExceptionResponse(Date date, String message, String description) {
		// TODO Auto-generated constructor stub
		date=this.date;
		message=this.message;
		description=this.description;
	}

}
