package com.inter.dbconnection;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class DataBaseExchange {
	
	@Autowired  
	JdbcTemplate jdbcTemplate;  
	@Autowired  
	private NamedParameterJdbcTemplate jdbcTemplates;  
	
	public String dbResult() {
		
	//	jdbcTemplate.execute("select id, dist,college from text where id=?")
		
		return "hi";
	}

	
	public String show() {
		Scanner sc=null;
		int id=0;
		Statement st=null;
		Connection con=null,con1=null;
		PreparedStatement ps=null,ps1=null, ps2=null;
		ResultSet rs=null , rs1=null,rs2=null;
		InputStream is=null;
		FileOutputStream fos=null;
		byte[] buffer=null;
		String dist=null;
		String college=null;
		String Path=null;
		String imageName=null ;
		int id1=0;
		int wrt=0;
		
		try{
			sc=new Scanner(System.in);
			
			/*
			 * if(sc!=null) System.out.println("enter id value"); id=sc.nextInt();
			 */
			//Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/interboard","root","root");
			con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/interboard","root","root");
			if(con!=null)
				
			  //String sql="select id,dist,college from text where id="+id;
			    ps=con.prepareStatement("select * from text ");
			    ps2=con.prepareStatement("update text set path=? where id=?");
			rs=ps.executeQuery();
			
			while(rs.next()){
				System.out.println("rs result ............");
				 id1=rs.getInt(1);
				dist=rs.getString(2);
				college=rs.getString(3);
				imageName=id1+".jpeg";
				
				Path="D:\\"+dist+"\\"+college+"\\"+imageName;
				System.out.println("dist:: "+dist+" \t college:: "+college);
				System.out.println("Path :: "+Path);
				//ps1.setInt(1, id);
				//rs1=ps1.executeQuery();
				boolean f=false;
				
				st=con1.createStatement();

				String sql="select * from image where id="+id1;
				rs1=st.executeQuery(sql);
				while(rs1.next()) {
					System.out.println("rs1 result ..........."+id1);
					System.out.println("rs1 id:: "+rs1.getInt(1)+"  ");
									f=true;
				}
				if(f==true) {
				 ps2.setString(1, Path);
				 ps2.setInt(2, id1);
				 ps2.executeLargeUpdate();
				 System.out.println("completed........");
				}else {
					System.out.println("record is not updated.. "+id1);
				}
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}

		finally{
			try{
				if(rs!=null)
					rs.close();
			}catch(Exception e){
				e.printStackTrace();
			}

			try{
				if(ps!=null)
					ps.close();
			}catch(Exception e){
				e.printStackTrace();
			}

			try{
				if(con!=null)
					con.close();
				sc.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}//finally

		
		
		return "";
	}
}
