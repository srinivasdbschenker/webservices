package com.nt.config;

public class MyConstants {
	public static final String MY_EMAIL="your mail id";
	public static final String MY_PASSWORD="your mail password";
	public static final String FRIEND_EMAIL="friends mail id";

}
