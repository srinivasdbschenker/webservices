package com.nt.conroller;

public class SimpleEmailController {

}
